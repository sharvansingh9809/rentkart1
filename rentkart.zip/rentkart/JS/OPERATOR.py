#arithmetic operator
print("*"*30)
print(" arithmetic  operator")
x=10
y=3
print(x+y)#13
print(x-y)#7
print(x/y)#3.3334
print(x*y)#30
print(x%y)#1
print(20/10)#2.0 normal division
print(20//10)#2 normal division
print(x**y)#1000  exponent operator
print(3**4)#81 
#COMPARISON OPERATOR
print("*"*30)
print("comparison operator")
x=10
y=3
print(x<3)
print(x>3)
print(x>=3)
print(x<=3)
print(23<=23)
print(10<20<30<40<100)#true
print(10>=50<30>=45<=60>=70<=1000)#false
print(True>=True)#true
#equality OPERATOR
print("*"*30)
print("equality operator")
x=10
y=3
print(x==y)#false
print(x!=y)#true
#MEMBERSHIP OPERATOR
print("*"*30)
print("MEMBERSHIP operator")
name="techpile technology private limited"
print("tech"  in "techpile technology")#true
print("tech" not in "techpile technology")#false
print("r" not in "welcome to code helper")#FALSE
print(" r" not in "welcome to code helpe r")#FALSE
#LOGICAL OPERATOR
print("*"*30)
print("LOGICAL operator")
#ASSIGNMENT  OPERATOR
print("*"*30)
print("ASSSIGNMENT  operator")
X=10
print(x)
x=x+20
print(x)






